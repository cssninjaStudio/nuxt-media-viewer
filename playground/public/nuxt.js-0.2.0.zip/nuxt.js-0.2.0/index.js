/*!
 * nuxt.js
 * MIT Licensed
 */

'use strict'

module.exports = require('./lib/nuxt')
