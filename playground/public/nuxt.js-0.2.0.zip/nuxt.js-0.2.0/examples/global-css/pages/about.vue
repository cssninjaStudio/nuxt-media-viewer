<template>
  <div class="content">
    <h1 class="title">Another Page</h1>
    <p><router-link to="/" class="button is-medium is-info hvr-wobble-vertical">Another button</router-link></p>
    <p><router-link to="/">Back home</router-link></p>
  </div>
</template>
