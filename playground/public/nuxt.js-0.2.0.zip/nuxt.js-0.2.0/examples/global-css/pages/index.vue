<template>
  <div class="content">
    <h1 class="title">Custom CSS!</h1>
    <p><router-link to="/about" class="button is-medium is-primary hvr-float-shadow">I am a button</router-link></p>
    <p><router-link to="/about">About page</router-link></p>
  </div>
</template>
