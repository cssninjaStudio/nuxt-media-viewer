<template>
  <div class="basic-css">
    <p>Hello World</p>
  </div>
</template>

<style>
.basic-css {
  font: 15px Helvetica, Arial, sans-serif;
  background: #eee;
  padding: 100px;
  text-align: center;
  transition: 100ms ease-in background;
}
.basic-css:hover {
  background: #ccc
}
</style>
