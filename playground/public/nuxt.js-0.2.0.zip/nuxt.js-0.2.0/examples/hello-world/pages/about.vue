<template>
  <div class="container">
    <img src="/static/nuxt.png" />
    <h2>About</h2>
    <p><router-link to='/'>Home</router-link></p>
  </div>
</template>

<style scoped>
.container {
  font-family: serif;
  margin-top: 200px;
  text-align: center;
}
</style>
