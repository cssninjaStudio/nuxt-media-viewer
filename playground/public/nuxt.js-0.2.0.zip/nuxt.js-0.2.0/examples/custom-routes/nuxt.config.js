module.exports = {
  routes: [
    { name: 'user', path: '/users/:id', component: 'pages/_user' }
  ]
}
