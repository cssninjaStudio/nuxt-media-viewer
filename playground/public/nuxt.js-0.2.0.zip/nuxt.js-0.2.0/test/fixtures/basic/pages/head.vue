<template>
  <div>
    <Head>
      <meta content='my meta' />
    </Head>
    <h1>I can haz meta tags</h1>
  </div>
</template>
