<template>
  <h1>My component!</h1>
</template>
