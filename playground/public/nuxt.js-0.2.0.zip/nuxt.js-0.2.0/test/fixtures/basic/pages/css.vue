<template>
  <div class="red">This is red</div>
</template>

<style>
.red {
  color: red;
}
</style>
